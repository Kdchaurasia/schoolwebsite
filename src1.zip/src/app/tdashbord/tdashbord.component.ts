import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-tdashbord',
  templateUrl: './tdashbord.component.html',
  styleUrls: ['./tdashbord.component.css']
})
export class TdashbordComponent implements OnInit {
  show: boolean = false

  obje:any
  showTable() {
    this.show = !this.show
  }
  constructor(private http: HttpClient,private services:AuthService,private route :Router ) { }
  showa: any
  getStudentDetails: any
  data:any
  ngOnInit(): void {
    this.http.get('http://localhost:3000/posts').subscribe((res) => { 
      this.data = res
      console.log(this.data);
    })

    this.http.get("http://localhost:3000/timeTable").subscribe((val) => {
      this.obje = val
    })
  }
  //edidForm validation
  edidForm = new FormGroup({
    userNameR: new FormControl(""),
    emailIdR: new FormControl(""),
    role: new FormControl(""),

  })
  viewStudent(std:any) {
    // console.log( std);
    // this.obje=Object.assign({},std)
    this.obje = std
  }
  cliks(val: any) {
    this.obje = val
  }

  updateProduct() {
    // close function
    let closeAuto = document.getElementById("close")
    closeAuto?.click()
    console.log(this.edidForm.value);
    this.services.editUpdate(this.obje).subscribe((val) => {
      console.log(val);
    })

  }


  submitTimetable = new FormGroup({
    firstrow1: new FormControl("", [Validators.required]),
    firstrow2: new FormControl("", [Validators.required]),
    firstrow3: new FormControl("", [Validators.required]),
    firstrow4: new FormControl("", [Validators.required]),

    secondRow1: new FormControl("", [Validators.required]),
    secondRow2: new FormControl("", [Validators.required]),
    secondRow3: new FormControl("", [Validators.required]),
    secondRow4: new FormControl("", [Validators.required]),

    thirdRow1: new FormControl("", [Validators.required]),
    thirdRow2: new FormControl("", [Validators.required]),
    thirdRow3: new FormControl("", [Validators.required]),
    thirdRow4: new FormControl("", [Validators.required]),

    fourthRow1: new FormControl("", [Validators.required]),
    fourthRow2: new FormControl("", [Validators.required]),
    fourthRow3: new FormControl("", [Validators.required]),
    fourthRow4: new FormControl("", [Validators.required])
  })
  
  // submit time table
  submit() { 
    this.services.postTimeTable(this.submitTimetable.value).subscribe((sub: any) => {
      console.log(sub);
    })
  }
  obj: any = { }
  logout(){
    this.route.navigate(["login"])
  }
  update(submitTimetable: any) {
    this.services.editTable(this.submitTimetable.value).subscribe((val:any) => {
      console.log(val);
      this.obj = val
    })
  }

}