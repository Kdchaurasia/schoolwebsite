import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SdashbordComponent } from './sdashbord/sdashbord.component';
import { TdashbordComponent } from './tdashbord/tdashbord.component';

const routes: Routes = [
  {path:"", redirectTo:"login",pathMatch:"full"},
  {path:"login",component:LoginComponent},
  {path:"sdashboard",component:SdashbordComponent},
  {path:"tdashboard",component:TdashbordComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
